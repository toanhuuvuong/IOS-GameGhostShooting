import SpriteKit
import GameplayKit

class GameScene: SKScene
{
    // --------------------------------------------- Attributes
    private let player: SKSpriteNode = SKSpriteNode(imageNamed: "player1") // Load ảnh người chơi
    
    private let labelScore: SKLabelNode = SKLabelNode(fontNamed: "Chalkduster") // Label hiển thị điểm
    
    private let jumpButton: SKSpriteNode = SKSpriteNode(imageNamed: "jump-button") // Nút jump (khi touch vào player sẽ jump lên)
    
    private let backgroundMusic: SKAudioNode = SKAudioNode(fileNamed: "background-music.caf") // Nhạc nền scene
    
    private var yPlayer: CGFloat = 0 // Vị trí đứng mặc định của player theo trục Y
    
    private var score: Int = 0  // Điểm
    
    private var highScore: Int = 0 // Điểm cao
    
    private var mode: Int = 0; // Mode chơi
    
    private var music: Bool = true // Cờ kiểm tra sound
    
    struct PhysicsCategory // Các loại vật lí mà object thuộc về
    {
        static let none: UInt32 = 0
        static let all: UInt32 = UInt32.max
        static let player: UInt32 = 0b1
        static let skyObstacle: UInt32 = 0b10
        static let groundObstacle: UInt32 = 0b11
        static let bullet: UInt32 = 0b100
    }
    // --------------------------------------------- Methods
    init(size: CGSize, music: Bool, highScore: Int, mode: Int) // ----------------------------------------------------------------------------
    {
        super.init(size: size)
        
        self.music = music
        
        self.highScore = highScore
        
        self.mode = mode
        
        // Thiết lập properties cho background
        let background: SKSpriteNode = SKSpriteNode(imageNamed: "background")
        background.zPosition = 0
        background.position = CGPoint(x: frame.size.width / 2, y: frame.size.height / 2)
        background.scale(to: size)
        addChild(background)
        
        // Nhạc nền
        if(music)
        {
            backgroundMusic.autoplayLooped = true // Tự động play lại khi hết nhạc
            addChild(backgroundMusic) // Thêm node music vào scene
        }
        
        // Môi trường vật lí của scene
        physicsWorld.gravity = .zero // Không trọng lực
        physicsWorld.contactDelegate = self // Uỷ quyền phát hiện collision cho scene
        
        // Thiết lập properties player
        yPlayer = size.height * 0.2
        player.position = CGPoint(x: size.width * 0.5, y: yPlayer)
        player.zPosition = 0.1
        player.physicsBody = SKPhysicsBody(rectangleOf: player.size) // Thiết lập cơ thể vật lí có kích cỡ rect
        player.physicsBody?.isDynamic = true // Cho phép môi trường vật lí tác động lên player
        player.physicsBody?.categoryBitMask = PhysicsCategory.player // Thiết lập loại vật lí mà player thuộc về (contact)
        player.physicsBody?.contactTestBitMask = PhysicsCategory.skyObstacle // Thiết lập loại vật lí của object contact với player
        player.physicsBody?.collisionBitMask = PhysicsCategory.none // Thiết lập loại vật lí của object collide với player (có hiệu ứng sau khi va chạm)
        addChild(player) // Thêm node player vào scene
        
        jumpButton.position = CGPoint(x: size.width * 0.5, y: size.height * 0.06) // Thiết lập vị trí của jump button
        jumpButton.zPosition = 0.1
        addChild(jumpButton) // Thêm node jump button vào scene
        
        // Thiết properties cho label hiển thị điểm
        labelScore.text = "SCORE: \(score)"
        labelScore.fontSize = 40.0
        labelScore.fontColor = UIColor.yellow
        labelScore.position = CGPoint(x: size.width * 0.5, y: size.height * 0.8)
        labelScore.zPosition = 0.1
        addChild(labelScore)
    }
    
    required init?(coder aDecoder: NSCoder)
    {
        fatalError("Error :(")
    }
    
    override func didMove(to view: SKView) // ----------------------------------------------------------------------------------------------------------------------------
    {
        // Thêm vạch kẻ đường line
        run(SKAction.repeatForever(SKAction.sequence([SKAction.run(addLine), SKAction.wait(forDuration: 0.2)])))
        
        // Thêm chướng ngại vật trên trời skyObstacle
        run(SKAction.repeatForever(SKAction.sequence([SKAction.wait(forDuration: 2.0), SKAction.run(addSkyObstacle)])))
        
        // Thêm chướng ngại vật trên đất groundObstacle
        run(SKAction.repeatForever(SKAction.sequence([SKAction.wait(forDuration: TimeInterval(10.0)), SKAction.run(addGroundObstacle)])))
    }
    
    // Phương thức được call khi kết thúc việc chạm
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) // ---------------------------------------------------------------------------------------------
    {
        // Chọn một trong các lần chạm để làm việc
        guard let touch: UITouch = touches.first else
        {
            return
        }
        
        if(music)
        {
            run(SKAction.playSoundFileNamed("pew-pew", waitForCompletion: false)) // Hiệu ứng âm thanh khi chạm
        }
        
        // Đổi trạng thái player
        player.run(SKAction.sequence([SKAction.run
        {
            self.player.removeFromParent()
            self.player.texture = SKTexture(imageNamed: "player2")
            self.addChild(self.player)
        },
        SKAction.wait(forDuration: 0.1),
        SKAction.run
        {
            self.player.removeFromParent()
            self.player.texture = SKTexture(imageNamed: "player1")
            self.addChild(self.player)
        }]))
        
        let touchLocation: CGPoint = touch.location(in: self) // Vị trí chạm trên scene
        
        if(jumpButton.contains(touchLocation)) // nếu nằm trong vùng của jump button
        {
            // Tạo chuỗi hành động jump
            let actionJump: SKAction = SKAction.move(to: CGPoint(x: player.position.x, y: yPlayer + 150), duration: 0.5)
            let actionJumpDone: SKAction = SKAction.move(to: CGPoint(x: player.position.x, y: yPlayer), duration: 1.5)
            player.run(SKAction.sequence([actionJump, actionJumpDone]))
        }
        else
        {
            let bullet: SKSpriteNode = SKSpriteNode(imageNamed: "bullet") // Load ảnh viên đạn bullet
            bullet.position = player.position // Thiết lập vị trí ban đầu của bullet
            bullet.zPosition = 0.1
            
            // Thiết lập các thông số vật lí
            bullet.physicsBody = SKPhysicsBody(circleOfRadius: bullet.size.width / 2)
            bullet.physicsBody?.isDynamic = true
            bullet.physicsBody?.categoryBitMask = PhysicsCategory.bullet
            bullet.physicsBody?.contactTestBitMask = PhysicsCategory.skyObstacle
            bullet.physicsBody?.collisionBitMask = PhysicsCategory.none
            bullet.physicsBody?.usesPreciseCollisionDetection = true // Tăng độ chính xác phát hiện contact & collison nhưng tốn kém hơn (đối với object nhỏ, di chuyển nhanh)
            addChild(bullet)
            
            let offset: CGPoint = touchLocation - bullet.position // Tính vector có hướng P(xPlayer, yPlayer) ----------> T(xTouch, yTouch)
            
            let direction: CGPoint = offset.normalized() // Tính vector đơn vị của vector PT
            
            let shootAmount: CGPoint = direction * 1000 // Nhân vector đơn vị cho 1000 (để đảm bảo vượt khỏi width của màn hình)
            
            let realDest: CGPoint = shootAmount + bullet.position // Tính điểm đích của viên đạn
            
            // Tạo chuỗi hành động shoot
            let actionShoot: SKAction = SKAction.move(to: realDest, duration: 1.5)
            let actionShootDone: SKAction = SKAction.removeFromParent()
            bullet.run(SKAction.sequence([actionShoot, actionShootDone]))
        }
    }
    
    func addSkyObstacle() // ----------------------------------------------------------------------------------------------------------------------------
    {
        let skyObstacle: SKSpriteNode = SKSpriteNode(imageNamed: "sky-obstacle") // Load ảnh của sky obstacle
        
        // Thiết lập các thông số vật lí
        skyObstacle.physicsBody = SKPhysicsBody(rectangleOf: skyObstacle.size)
        skyObstacle.physicsBody?.isDynamic = true
        skyObstacle.physicsBody?.categoryBitMask = PhysicsCategory.skyObstacle
        skyObstacle.physicsBody?.contactTestBitMask = PhysicsCategory.player
        skyObstacle.physicsBody?.collisionBitMask = PhysicsCategory.none
        
        // Random toạ độ xuất hiện trên của sky obstacle dọc 2 trục đứng
        let actualY: CGFloat = random(min: player.position.y + 40.0, max: size.height - skyObstacle.size.height / 2)
        skyObstacle.position = CGPoint(x: (arc4random() % 2 == 0) ? -skyObstacle.size.width / 2 : size.width + skyObstacle.size.width / 2, y: actualY)
        skyObstacle.zPosition = 0.1
        
        addChild(skyObstacle)
        
        // Random tốc độ di chuyển của sky obstacle
        var actualDuration: CGFloat = 0
        if(mode == 1)
        {
            actualDuration = random(min: 10.0, max: 15.0)
        }
        else if (mode == 2)
        {
            actualDuration = random(min: 5.0, max: 10.0)
        }
        else
        {
            actualDuration = random(min: 2.0, max: 5.0)
        }
        
        let offset: CGPoint = player.position - skyObstacle.position
        
        let direction: CGPoint = offset.normalized()
        
        let shootAmount: CGPoint = direction * 1000
        
        let realDest: CGPoint = shootAmount + skyObstacle.position
        
        // Tạo hành động move hướng đến player của sky obstacle
        let actionMove = SKAction.move(to: realDest, duration: TimeInterval(actualDuration))
        let actionMoveDone = SKAction.removeFromParent()
        skyObstacle.run(SKAction.sequence([actionMove, actionMoveDone]))
    }
    
    func addGroundObstacle() // ----------------------------------------------------------------------------------------------------------------------------
    {
        let groundObstacle: SKSpriteNode = SKSpriteNode(imageNamed: "ground-obstacle") // Load ảnh của ground obstacle
        
        // Thiết lập các thông số vật lí
        groundObstacle.physicsBody = SKPhysicsBody(rectangleOf: groundObstacle.size)
        groundObstacle.physicsBody?.isDynamic = true
        groundObstacle.physicsBody?.categoryBitMask = PhysicsCategory.groundObstacle
        groundObstacle.physicsBody?.contactTestBitMask = PhysicsCategory.player
        groundObstacle.physicsBody?.collisionBitMask = PhysicsCategory.none
        
        // Thiết lập vị trí ban đầu của ground obstacle
        let actualY: CGFloat = yPlayer - 20.0
        groundObstacle.position = CGPoint(x: size.width + groundObstacle.size.width / 2, y: actualY)
        groundObstacle.zPosition = 0.1
        
        addChild(groundObstacle)
        
        // Random tốc độ di chuyển của ground obstacle
        var actualDuration: CGFloat = 0
        if(mode == 1)
        {
            actualDuration = random(min: 5.0, max: 7.0)
        }
        else if (mode == 2)
        {
            actualDuration = random(min: 3.0, max: 5.0)
        }
        else
        {
            actualDuration = random(min: 1.0, max: 3.0)
        }
        
        // Tạo hành động move ngang + xoay của ground obstacle
        let actionMove = SKAction.move(to: CGPoint(x: -groundObstacle.size.width / 2, y: actualY), duration: TimeInterval(actualDuration))
        let actionMoveDone = SKAction.removeFromParent()
        groundObstacle.run(SKAction.repeatForever(SKAction.sequence([SKAction.rotate(toAngle: 180, duration: 0.5), SKAction.wait(forDuration: 0.1)])))
        groundObstacle.run(SKAction.sequence([actionMove, actionMoveDone]))
    }
    
    func addLine() // ----------------------------------------------------------------------------------------------------------------------------
    {
        let line: SKSpriteNode = SKSpriteNode(imageNamed: "line") // Load ảnh của line
    
        // Thiết lập vị trí ban đầu của line
        let actualY: CGFloat = yPlayer - player.size.height / 2 - line.size.height / 2
        line.position = CGPoint(x: size.width + line.size.width / 2, y: actualY)
        line.zPosition = 0.1
        
        addChild(line)
        
        // Tạo hành động move ngang của line
        let actionMove = SKAction.move(to: CGPoint(x: -line.size.width / 2, y: actualY), duration: 1.0)
        let actionMoveDone = SKAction.removeFromParent()
        line.run(SKAction.sequence([actionMove, actionMoveDone]))
    }
    
    func bulletDidCollideWithSkyObstacle(bullet: SKSpriteNode, skyObstacle: SKSpriteNode) // ---------------------------------------------------------
    {
        bullet.removeFromParent() // Xoá bullet khỏi scene
        
        // Đổi trang thái của sky obstacle trước khi xoá khỏi scene
        skyObstacle.run(SKAction.sequence([SKAction.run
        {
            skyObstacle.removeFromParent() // Xoá sky obstacle khỏi scene
            skyObstacle.texture = SKTexture(imageNamed: "sky-obstacle-die")
            self.addChild(skyObstacle)
        },
        SKAction.run
        {
            skyObstacle.removeFromParent()
        }]))
        
        score += 1
        labelScore.text = "SCORE: \(score)"
        labelScore.removeFromParent()
        addChild(labelScore)
        
        if(score == 30)
        {
            // Run game over scene
            let gameOverScene: GameOverScene = GameOverScene(size: size, won: true, score: score, highScore: highScore)
            let transition: SKTransition = SKTransition.flipVertical(withDuration: 0.5)
            view?.presentScene(gameOverScene, transition: transition)
        }
    }
    
    func playerDidCollideWithObstacle() // -----------------------------------------------------------------------------------------------------------
    {
        // Run game over scene
        let gameOverScene: GameOverScene = GameOverScene(size: size, won: false, score: score, highScore: highScore)
        let transition: SKTransition = SKTransition.flipVertical(withDuration: 0.5)
        view?.presentScene(gameOverScene, transition: transition)
    }
}

extension GameScene: SKPhysicsContactDelegate
{
    func didBegin(_ contact: SKPhysicsContact)
    {
        var firstBody: SKPhysicsBody
        var secondBody: SKPhysicsBody
        
        if(contact.bodyA.categoryBitMask < contact.bodyB.categoryBitMask)
        {
            firstBody = contact.bodyA
            secondBody = contact.bodyB
        }
        else
        {
            firstBody = contact.bodyB
            secondBody = contact.bodyA
        }
        
        if((firstBody.categoryBitMask == PhysicsCategory.skyObstacle) && (secondBody.categoryBitMask == PhysicsCategory.bullet))
        {
            if let skyObstacle = firstBody.node as? SKSpriteNode, let bullet = secondBody.node as? SKSpriteNode
            {
                bulletDidCollideWithSkyObstacle(bullet: bullet, skyObstacle: skyObstacle)
            }
        }
        else if ((firstBody.categoryBitMask == PhysicsCategory.player) &&
            ((secondBody.categoryBitMask == PhysicsCategory.skyObstacle) || (secondBody.categoryBitMask == PhysicsCategory.groundObstacle)))
        {
            playerDidCollideWithObstacle()
        }
    }
}
