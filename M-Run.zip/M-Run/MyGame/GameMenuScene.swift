import SpriteKit

class GameMenuScene: SKScene
{
    // ------------------------------------------------- Attributes
    private let soundButton: SKSpriteNode = SKSpriteNode(imageNamed: "sound-on") // Nút bật/tắt nhạc nền
    
    private let playButton: SKSpriteNode = SKSpriteNode(imageNamed: "player1") // Nút chơi ngay
    
    private let easyButton:  SKSpriteNode = SKSpriteNode(imageNamed: "easy-mode") // Mode dễ
    
    private let hardButton:  SKSpriteNode = SKSpriteNode(imageNamed: "hard-mode") // Mode khó
    
    private let veryHardButton:  SKSpriteNode = SKSpriteNode(imageNamed: "very-hard-mode") // Mode rất khó
    
    let labelSound: SKLabelNode = SKLabelNode(fontNamed: "Chalkduster") // Label mô tả nút sound
    
    let labelPlay: SKLabelNode = SKLabelNode(fontNamed: "Chalkduster") // Label mô tả nút play
    
    let labelEasy: SKLabelNode = SKLabelNode(fontNamed: "Chalkduster") // Label mô tả nút easy mode
    
    let labelHard: SKLabelNode = SKLabelNode(fontNamed: "Chalkduster") // Label mô tả nút hard mode
    
    let labelVeryHard: SKLabelNode = SKLabelNode(fontNamed: "Chalkduster") // Label mô tả nút very hard mode
    
    private var music: Bool = true // Cờ kiểm tra music
    
    private var mode: Int = 1 // Mode chơi
    
    private var highScore: Int = 0 // Điểm cao
    // ------------------------------------------------- Methods
    init(size: CGSize, highScore: Int)
    {
        super.init(size: size)
        
        self.highScore = highScore
        
        // Thiết lập properties cho background
        let background: SKSpriteNode = SKSpriteNode(imageNamed: "background")
        background.zPosition = 0
        background.position = CGPoint(x: frame.size.width / 2, y: frame.size.height / 2)
        background.scale(to: size)
        addChild(background)
        
        // Thiết lập properties cho nút sound
        soundButton.position = CGPoint(x: size.width * 0.8, y: size.height * 0.9)
        soundButton.zPosition = 0.1
        addChild(soundButton)
        labelSound.position = CGPoint(x: size.width * 0.8, y: size.height * 0.8)
        labelSound.text = "Sound on"
        labelSound.fontSize = 20.0
        labelSound.fontColor = UIColor.orange
        labelSound.zPosition = 0.1
        addChild(labelSound)
        
        // Thiết lập properties cho nút play
        playButton.position = CGPoint(x: size.width * 0.5, y: size.height * 0.6)
        playButton.zPosition = 0.1
        addChild(playButton)
        labelPlay.position = CGPoint(x: size.width * 0.5, y: size.height * 0.48)
        labelPlay.text = "PLAY NOW!"
        labelPlay.fontSize = 20.0
        labelPlay.fontColor = UIColor.blue
        labelPlay.zPosition = 0.1
        addChild(labelPlay)
        
        // Thiết lập properties cho mode dễ
        easyButton.position = CGPoint(x: size.width * 0.2, y: size.height * 0.4)
        easyButton.zPosition = 0.1
        addChild(easyButton)
        labelEasy.position = CGPoint(x: size.width * 0.2, y: size.height * 0.3)
        labelEasy.text = "Easy"
        labelEasy.fontSize = 20.0
        labelEasy.fontColor = UIColor.yellow
        labelEasy.zPosition = 0.1
        addChild(labelEasy)
        
        // Thiết lập properties cho mode khó
        hardButton.position = CGPoint(x: size.width * 0.5, y: size.height * 0.4)
        hardButton.zPosition = 0.1
        addChild(hardButton)
        labelHard.position = CGPoint(x: size.width * 0.5, y: size.height * 0.3)
        labelHard.text = "Hard"
        labelHard.fontSize = 20.0
        labelHard.fontColor = UIColor.green
        labelHard.zPosition = 0.1
        addChild(labelHard)
        
        // Thiết lập properties cho mode rất khó
        veryHardButton.position = CGPoint(x: size.width * 0.8, y: size.height * 0.4)
        veryHardButton.zPosition = 0.1
        addChild(veryHardButton)
        labelVeryHard.position = CGPoint(x: size.width * 0.8, y: size.height * 0.3)
        labelVeryHard.text = "Very hard"
        labelVeryHard.fontSize = 20.0
        labelVeryHard.fontColor = UIColor.red
        labelVeryHard.zPosition = 0.1
        addChild(labelVeryHard)
    }
    
    required init?(coder aDecoder: NSCoder)
    {
        fatalError("Error :(")
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        // Chọn một trong các lần chạm để làm việc
        guard let touch: UITouch = touches.first else
        {
            return
        }
        
        if(music)
        {
            run(SKAction.playSoundFileNamed("pew-pew", waitForCompletion: false)) // Hiệu ứng âm thanh khi chạm
        }
        
        let touchLocation: CGPoint = touch.location(in: self) // Vị trí chạm trên scene
        
        if(soundButton.contains(touchLocation)) // nếu nằm trong vùng của sound button
        {
            
            soundButton.removeFromParent()
            labelSound.removeFromParent()
            
            if(music)
            {
                music = false
                soundButton.texture = SKTexture(imageNamed: "sound-off")
                labelSound.text = "Sound off"
                
            }
            else
            {
                music = true
                soundButton.texture = SKTexture(imageNamed: "sound-on")
                labelSound.text = "Sound on"
            }
            
            addChild(soundButton)
            addChild(labelSound)
        }
        else if(playButton.contains(touchLocation) || labelPlay.contains(touchLocation)) // nếu nằm trong vùng của play button hoặc play label
        {
            // Phóng to play label
            labelPlay.removeFromParent()
            labelPlay.fontSize = 30.0
            labelPlay.fontColor = UIColor.orange
            addChild(labelPlay)
            
            // Đổi player
            playButton.removeFromParent()
            playButton.texture = SKTexture(imageNamed: "player2")
            addChild(playButton)
            
            // Chạy game scene
            run(SKAction.sequence([SKAction.wait(forDuration: 0.1),
                                   SKAction.run()
                                    {
                                        [weak self] in
                                        guard let `self` = self else { return }
                                        let transition = SKTransition.flipVertical(withDuration: 0.5)
                                        let gameScene = GameScene(size: self.size, music: self.music, highScore: self.highScore, mode: self.mode)
                                        self.view?.presentScene(gameScene, transition: transition)
                                     }]))
        }
        else if(easyButton.contains(touchLocation)) // nếu nằm trong vùng của easy button
        {
            if(mode == 2)
            {
                hardButton.texture = SKTexture(imageNamed: "hard-mode")
            }
            else if(mode == 3)
            {
                veryHardButton.texture = SKTexture(imageNamed: "very-hard-mode")
            }
            mode = 1
            easyButton.texture = SKTexture(imageNamed: "easy-mode-choosed")
        }
        else if(hardButton.contains(touchLocation)) // nếu nằm trong vùng của hard button
        {
            if(mode == 1)
            {
                easyButton.texture = SKTexture(imageNamed: "easy-mode")
            }
            else if(mode == 3)
            {
                veryHardButton.texture = SKTexture(imageNamed: "very-hard-mode")
            }
            mode = 2
            hardButton.texture = SKTexture(imageNamed: "hard-mode-choosed")
        }
        else if(veryHardButton.contains(touchLocation)) // nếu nằm trong vùng của very hard button
        {
            if(mode == 1)
            {
                easyButton.texture = SKTexture(imageNamed: "easy-mode")
            }
            else if(mode == 2)
            {
                hardButton.texture = SKTexture(imageNamed: "hard-mode")
            }
            mode = 3
            veryHardButton.texture = SKTexture(imageNamed: "very-hard-mode-choosed")
        }
    }
}
