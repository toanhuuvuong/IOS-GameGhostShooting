import UIKit
import SpriteKit
import GameplayKit

class GameViewController: UIViewController
{
    // Phương thức được call khi khung nhìn view đã được load
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        let skView: SKView = self.view as! SKView // Ép kiếu UIView -> SKView
        skView.ignoresSiblingOrder = true // Quan hệ giữa các node không ảnh hưởng đến thứ tự render
        skView.showsFPS = false // Hiển thị frame rate (debug)
        skView.showsNodeCount = false // Hiển thị số lượng node đang có trên scene (debug)
        
        let gameMenuScene: GameMenuScene = GameMenuScene(size: skView.bounds.size, highScore: 0) // Tạo khung cảnh menu scene (hiển thị nội dung game)
        gameMenuScene.scaleMode = .resizeFill // Scale kích cỡ menu scene cho phù hợp với view
                
        skView.presentScene(gameMenuScene) // Trình bày khung cảnh menu scene
    }
    
    // Tự động xoay màn hình
    override var shouldAutorotate: Bool
    {
        return true
    }

    override var supportedInterfaceOrientations: UIInterfaceOrientationMask
    {
        if UIDevice.current.userInterfaceIdiom == .phone
        {
            return .allButUpsideDown
        }
        else
        {
            return .all
        }
    }

    override var prefersStatusBarHidden: Bool
    {
        return true
    }
}
