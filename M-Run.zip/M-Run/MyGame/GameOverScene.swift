import SpriteKit

class GameOverScene: SKScene
{
    init(size: CGSize, won: Bool, score: Int, highScore: Int)
    {
        super.init(size: size)
        
        // Thiết lập properties cho background
        let background: SKSpriteNode = SKSpriteNode(imageNamed: "background")
        background.zPosition = 0
        background.position = CGPoint(x: frame.size.width / 2, y: frame.size.height / 2)
        background.scale(to: size)
        addChild(background)
        
        // Thiết lập properties cho message thông báo win/lost
        let message: String = (won) ? "You won!" : "You lost :("
        let labelMessage: SKLabelNode = SKLabelNode(fontNamed: "Chalkduster")
        labelMessage.position = CGPoint(x: size.width * 0.5, y: size.height * 0.5)
        labelMessage.text = message
        labelMessage.fontSize = 40.0
        labelMessage.fontColor = UIColor.yellow
        labelMessage.zPosition = 0.1
        addChild(labelMessage)
        
        // Thiết lập properties cho điểm
        let labelScore: SKLabelNode = SKLabelNode(fontNamed: "Chalkduster")
        labelScore.position = CGPoint(x: size.width * 0.5, y: size.height * 0.4)
        labelScore.text = "Score: \(score)"
        labelScore.fontSize = 40.0
        labelScore.fontColor = UIColor.yellow
        labelScore.zPosition = 0.1
        addChild(labelScore)
        
        // Thiết lập properties cho điểm cao
        let labelHighScore: SKLabelNode = SKLabelNode(fontNamed: "Chalkduster")
        labelHighScore.position = CGPoint(x: size.width * 0.5, y: size.height * 0.3)
        labelHighScore.text = (highScore > score) ? "High score: \(highScore)" : "New high score: \(score)"
        labelHighScore.fontSize = 30.0
        labelHighScore.fontColor = UIColor.yellow
        labelHighScore.zPosition = 0.1
        addChild(labelHighScore)
        
        // Trở về menu scene
        run(SKAction.sequence([SKAction.wait(forDuration: 3.0),
            SKAction.run()
            {
                [weak self] in
                guard let `self` = self else { return }
                let transition = SKTransition.flipVertical(withDuration: 0.5)
                let gameMenuScene = GameMenuScene(size: size, highScore: (highScore > score) ? highScore : score)
                self.view?.presentScene(gameMenuScene, transition: transition)
            }]))
    }
    
    required init?(coder aDecoder: NSCoder)
    {
        fatalError("Error :(")
    }
}
